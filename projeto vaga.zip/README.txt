Arquivo SQL - lear.sql 
Pasta Lear - Lear 
Desenvolvido em PHP e SQL
O projeto deverá ser executado em Servidor Apache
SQL deverá ser importado em Banco de Dados SQL
Obs: As credenciais para acesso ao banco de dados deveram ser alterado nos arquivos cadastrar.php e listar.php dentro da pasta banco_dados , caso não use XAMPP,WAMPP (ou software similar) para teste de sistema.
