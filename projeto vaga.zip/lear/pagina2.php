<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous"><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <script type="text/javascript" src="js/main.js"></script>
    <title></title>
  </head>
  <body>

    <h1>Página de Cadastro</h1>

    <form class="" action="banco_dados/cadastrar.php" method="post">

      <label>Nome do Anúncio</label>
      <input type="text" class="form-control" name="nome" value="">

      <label>Cliente</label>
      <input type="text" class="form-control" name="cliente" value="">

      <label>Data do Inicio</label>
      <input type="date" class="form-control" name="data_inicio" value="">

      <label>Data do Término</label>
      <input type="date" class="form-control" name="data_termino" value="">

      <label>Investimento por Dia</label>
      <input type="number" class="form-control" id="investimento" name="investimento_dia" value="" onchange="calcular()">

      <label>Visualizações</label>
      <input type="number" class="form-control" id="visualizacoes" name="visualizacoes" value="">

      <label>Números de Cliques</label>
      <input type="number" class="form-control" id="numero_cliques" name="numero_cliques" value="">

      <label>Número Máximo de Compartilhamento</label>
      <input type="number" class="form-control" id="numero_maximo_compartilhamento" name="numero_maximo_compartilhamento" value="">


      <button type="submit" class="btn btn-success" name="button">Cadastrar</button>

    </form>

  </body>
</html>
