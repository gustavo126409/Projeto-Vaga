<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Cadastro de Campanha</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
  </head>
  <body>

      <?php include 'banco_dados/listar.php'; ?>

      <h1>Lista de Anúncios</h1>

      <div class="row">
        <div class="col-md-3">
          <a class="btn btn-success" href="pagina2.php">Cadastrar</a>
        </div>
        <div class="col-md-9">
          <form action="/lear/" method="get">
            <div class="row">
              <div class="col-md-3">
                <input type="date" class="form-control" name="data_inicio" value="<?php if(isset($_GET['data_inicio'])){ echo $_GET["data_inicio"]; } ?>">
              </div>
              <div class="col-md-3">
                <input type="date" class="form-control" name="data_termino" value="<?php if(isset($_GET['data_termino'])){ echo $_GET["data_termino"]; } ?>">
              </div>
              <div class="col-md-3">
                <input type="text" class="form-control" name="cliente" value="<?php if(isset($_GET['cliente'])){ echo $_GET["cliente"]; } ?>">
              </div>
              <div class="col-md-3">
                <button type="submit" class="btn btn-danger btn-block" name="button">Filtrar</button>
              </div>
            </div>
          </form>
        </div>
      </div>


      <br>

      <?php $total = 0; ?>


      <table class="table table-bordered">
        <tr>
          <td>Nome do Anúncio</td>
          <td>Cliente</td>
          <td>Data de Inicio</td>
          <td>Data de Término</td>
          <td>Valor</td>
        </tr>
        <?php foreach($info as $valor){ ?>
          <?php $total += $valor['investimento_dia']; ?>
          <tr>
            <td><?php echo $valor['nome']; ?></td>
            <td><?php echo $valor['cliente']; ?></td>
            <td><?php echo date('d/m/Y', strtotime($valor['data_inicio'])); ?></td>
            <td><?php echo  date('d/m/Y', strtotime($valor['data_final'])); ?></td>
            <td>R$ <?php echo $valor['investimento_dia']; ?></td>
          </tr>
        <?php } ?>
        <tr>
          <td colspan="4">Total</td>
          <td><?php echo 'R$'.$total; ?></td>
        </tr>
      </table>

  </body>
</html>
