<?php

    //Informações do Banco de Dados que irá armazenar as Informações
    $servidor = 'localhost';
    $usuario = 'root';
    $senha = '';
    $banco_dados = 'lear';

    //Iniciar a Conexão
    $conn = new mysqli($servidor, $usuario, $senha, $banco_dados);

    //Inset Into = Função SQL de Cadastro
    //Campanha = nome da tabela

    //$_POST = Recebe o valor dos Campos
    //[""] = nome do campo

    $nome = $_POST["nome"];
    $cliente = $_POST["cliente"];
    $data_inicio = $_POST["data_inicio"];
    $data_termino = $_POST["data_termino"];
    $valor_investimento = $_POST["investimento_dia"];
    $visualizacoes = $_POST["visualizacoes"];
    $numeroCliques = $_POST["numero_cliques"];
    $numeroMaximoCompartilhamento = $_POST["numero_maximo_compartilhamento"];

    //Comanda no Banco
    $sql = "INSERT INTO campanha(`nome`,`cliente`, `data_inicio`, `data_final`, `investimento_dia`, `visualizacoes`, `numero_cliques`, `numero_maximo_compartilhamento`)
      VALUES('$nome', '$cliente', '$data_inicio', '$data_termino', '$valor_investimento', '$visualizacoes', '$numeroCliques', '$numeroMaximoCompartilhamento')";


    //Executar o comando e receber o retorno
    if($conn->query($sql)){
      header("Location: ../index.php");
    }


?>
