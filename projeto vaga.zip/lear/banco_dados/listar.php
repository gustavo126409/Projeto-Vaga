<?php

    //Informações do Banco de Dados que irá armazenar as Informações
    $servidor = 'localhost';
    $usuario = 'root';
    $senha = '';
    $banco_dados = 'lear';

    //Iniciar a Conexão
    $conn = new mysqli($servidor, $usuario, $senha, $banco_dados);

    //SELECT = Selecionar as informações
    //* = Todas as Informações
    //FROM = Qual tabela selecionar

    //Comanda no Banco
    $sql = "SELECT * FROM campanha";

    if(isset($_GET['data_inicio'])){
        $data_inicio = $_GET['data_inicio'];
        $sql .= "   WHERE data_inicio >='$data_inicio'";
    }

    if(isset($_GET['data_termino'])&&$_GET['data_termino']!=""){
        $data_termino = $_GET['data_termino'];
        if($_GET['data_inicio']!=""){
          $sql .= "   AND data_final <='$data_termino'";
        }else{
          $sql .= "   WHERE data_final <='$data_termino'";
        }
    }

    if(isset($_GET['cliente'])&&$_GET["cliente"]!=""){
      $cliente = $_GET['cliente'];
      if($_GET['data_inicio']!=""||$_GET['data_termino']!=""){
        $sql .= "   AND cliente  LIKE '$cliente'";
      }else{
        $sql .= "   WHERE cliente  LIKE '$cliente'";
      }
    }



    //Executar o comando e receber o retorno
    $query = $conn->query($sql);

    $info = array();

    //Armazenar todos os dados do banco  em uma variável PHP
    while($valor = mysqli_fetch_assoc($query)){
      $info[] = $valor;
    }

    // $info = Único dado (Só pode armazenar um único dado)
    // $info[] = Vários dados de diferentes tipos

?>
