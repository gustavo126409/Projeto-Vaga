function calcular(){

    var investimento_dia = document.getElementById('investimento').value;
    var visualizacoes = 0;
    var numero_maximo_compartilhamento = 0;
    var numero_cliques = 0;

    visualizacoes = investimento_dia * 30;
    document.getElementById('visualizacoes').value = visualizacoes;

    if(visualizacoes >= 100){
      var diferenca = visualizacoes % 100;
      if(diferenca > 0){
        quantidade = visualizacoes - diferenca;
      }else{
        quantidade = visualizacoes;
      }
      numero_cliques = (quantidade / 100) * 12;
      document.getElementById('numero_cliques').value = numero_cliques;
    }else{
      document.getElementById('numero_cliques').value = 0;
    }

    if(numero_cliques >= 20){
      var diferenca = numero_cliques % 20;
      if(diferenca > 0){
        quantidade = numero_cliques - diferenca;
      }else{
        quantidade = numero_cliques;
      }
      document.getElementById('numero_maximo_compartilhamento').value = ((quantidade / 20) * 3) * 4;
    }else{
      document.getElementById('numero_maximo_compartilhamento').value = 0;
    }

}
