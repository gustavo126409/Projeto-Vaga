-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 16-Maio-2021 às 04:28
-- Versão do servidor: 10.4.18-MariaDB
-- versão do PHP: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `lear`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `campanha`
--

CREATE TABLE `campanha` (
  `id` int(11) NOT NULL,
  `nome` varchar(45) NOT NULL,
  `cliente` varchar(45) NOT NULL,
  `data_inicio` date NOT NULL,
  `data_final` date NOT NULL,
  `investimento_dia` varchar(10) NOT NULL,
  `visualizacoes` int(11) NOT NULL,
  `numero_cliques` int(11) NOT NULL,
  `numero_maximo_compartilhamento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `campanha`
--

INSERT INTO `campanha` (`id`, `nome`, `cliente`, `data_inicio`, `data_final`, `investimento_dia`, `visualizacoes`, `numero_cliques`, `numero_maximo_compartilhamento`) VALUES
(7, 'Teste', 'Gustavo', '2021-05-01', '2021-05-31', '13', 0, 0, 0),
(8, 'Teste 2', 'Ruan', '2021-06-01', '2021-06-30', '13', 0, 0, 0),
(9, 'Ruan Kaique', 'Teste 3', '2021-06-01', '2021-06-30', '120', 0, 0, 0),
(11, 'Teste', 'Gustavo', '2021-05-30', '2020-06-18', '10', 300, 36, 12),
(12, 'Teste', 'Gustavo', '2021-05-30', '2021-06-18', '10', 300, 36, 12);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `campanha`
--
ALTER TABLE `campanha`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `campanha`
--
ALTER TABLE `campanha`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
